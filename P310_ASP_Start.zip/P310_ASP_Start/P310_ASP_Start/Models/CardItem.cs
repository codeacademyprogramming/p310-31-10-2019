﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using P310_ASP_Start.Models;

namespace P310_ASP_Start.Models
{
    public class CardItem
    {
        public Product Product { get; set; }
        public byte Count { get; set; }
    }
}
