﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using P310_ASP_Start.Models;
using P310_ASP_Start.DAL;
using Newtonsoft.Json;

namespace P310_ASP_Start.Controllers
{
    public class CartController : Controller
    {
        private readonly EliteContext _context;

        public CartController(EliteContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Add(int id)
        {
            var cart = new List<CardItem>();

            var cartSession = HttpContext.Session.GetString("cart");
            if (cartSession != null)
            {
                cart = JsonConvert.DeserializeObject<List<CardItem>>(cartSession);
                
                if(cart.Any(c => c.Product.Id == id))
                {
                    CardItem cardItem = cart.First(c => c.Product.Id == id);
                    cardItem.Count++;
                }
                else
                {
                    cart.Add(new CardItem
                    {
                        Product = await _context.Products.FindAsync(id),
                        Count = 1
                    });
                }
            }
            else
            {
                cart.Add(new CardItem
                {
                    Product = await _context.Products.FindAsync(id),
                    Count = 1
                });
            }
            
            string jsonList = JsonConvert.SerializeObject(cart);
            HttpContext.Session.SetString("cart", jsonList);

            //int cou = 0;
            //for(int i=0; i<cart.Count; i++)
            //{
            //    cou += cart[i].Count;
            //}


            return Json(new
            {
                status = 200,
                message = "New product was successfully added to cart",
                //data = cart.Count
                data = cart.Sum(c => c.Count)
            }) ;
        }
    }
}